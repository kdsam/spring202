package com.springinaction.knights;

public class Minstrel {
  public void singBeforeQuest() {
    System.out.println("Fa la la; The knight is so brave!");
  }
  
  public void singAfterQuest() {
    System.out.println("Tee hee he; The brave knight did embark on a quest!");
  }
}
