package com.kensbunker.practice.algorithms.list;

public class _002_EmployeeNode {

    private Employee employee;
    private _002_EmployeeNode next;

    public _002_EmployeeNode(Employee employee) {
        this.employee = employee;
    }

    public Employee getEmployee() {
        return employee;
    }

    public void setEmployee(Employee employee) {
        this.employee = employee;
    }

    public _002_EmployeeNode getNext() {
        return next;
    }

    public void setNext(_002_EmployeeNode next) {
        this.next = next;
    }

    @Override
    public String toString() {
        return employee.toString();
    }
}
