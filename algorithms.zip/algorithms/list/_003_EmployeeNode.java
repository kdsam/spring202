package com.kensbunker.practice.algorithms.list;

public class _003_EmployeeNode {

    private Employee employee;
    private _003_EmployeeNode next;
    private _003_EmployeeNode previous;

    public _003_EmployeeNode(Employee employee) {
        this.employee = employee;
    }

    public Employee getEmployee() {
        return employee;
    }

    public void setEmployee(Employee employee) {
        this.employee = employee;
    }

    public _003_EmployeeNode getNext() {
        return next;
    }

    public void setNext(_003_EmployeeNode next) {
        this.next = next;
    }

    public _003_EmployeeNode getPrevious() {
        return previous;
    }

    public void setPrevious(_003_EmployeeNode previous) {
        this.previous = previous;
    }

    @Override
    public String toString() {
        return employee.toString();
    }
}
