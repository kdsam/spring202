package com.kensbunker.practice.algorithms.list;

public class _002_EmployeeLinkedList {

    private _002_EmployeeNode head;
    private int size;

    public void addToFront(Employee employee) {
        _002_EmployeeNode node = new _002_EmployeeNode(employee);
        node.setNext(head);
        head = node;
        size++;
    }

    public int getSize() {
        return size;
    }

    public boolean isEmpty() {
        return head == null;
    }

    public _002_EmployeeNode removeFromFront() {
        if (isEmpty()) {
            return null;
        }

        _002_EmployeeNode removedNode = head;
        head = head.getNext();
        size--;
        removedNode.setNext(null);
        return removedNode;
    }

    public void printList() {
        _002_EmployeeNode current = head;
        System.out.print("HEAD -> ");
        while (current != null) {
            System.out.print(current);
            System.out.print(" -> ");
            current = current.getNext();
        }

        System.out.println("null");
    }
}
