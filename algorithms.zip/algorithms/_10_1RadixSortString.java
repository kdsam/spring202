package com.kensbunker.practice.algorithms;

public class _10_1RadixSortString {

    public static void main(String[] args) {
        String[] stringsArray = {"bcdef", "dbaqc", "abcde", "omadd", "bbbbb"};

        // do radix sort

        radixSort(stringsArray, 26, 5);

        for (int i = 0; i < stringsArray.length; i++) {
            System.out.println(stringsArray[i]);
        }
    }

    public static void radixSort(String[] input, int radix, int width) {
        for (int i = width - 1; i >=0; i--) {
            radixSingleSort(input, i, radix);
        }
    }

    public static void radixSingleSort(String[] input, int position, int radix) {

        int numItems = input.length;
        int[] countArray = new int[radix];

        //populate count of each characters
        for (String value : input) {
            countArray[getCharIndex(position, value)]++;
        }

        //adjust count array
        for (int i = 1; i < radix; i++) {
            countArray[i] += countArray[i - 1];
        }


        //Reorder strings in temp array
        String[] temp = new String[numItems];

        for (int tempIndex = numItems - 1; tempIndex >= 0; tempIndex--) {
            temp[--countArray[getCharIndex(position, input[tempIndex])]] = input[tempIndex];
        }

        for (int tempIndex = 0; tempIndex < numItems; tempIndex++) {
            input[tempIndex] = temp[tempIndex];
        }

    }

    // remove radix
    // simply use 'value.charAt(position) - a' and get rid of firstNumericChar
    public static int getCharIndex(int position, String value) {
        return value.charAt(position) - 'a';
    }

}
